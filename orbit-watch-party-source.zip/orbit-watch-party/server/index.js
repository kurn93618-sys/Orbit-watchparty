import express from 'express';
import rateLimit from 'express-rate-limit';
import { randomUUID } from 'node:crypto';
import { AccessToken } from 'livekit-server-sdk';

const app = express();
const port = Number(process.env.PORT || 3000);
const livekitUrl = process.env.LIVEKIT_URL;
const apiKey = process.env.LIVEKIT_API_KEY;
const apiSecret = process.env.LIVEKIT_API_SECRET;
const rooms = new Map();

app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'orbit-token-server' }));

// Public rooms are discoverable; private rooms never appear in this directory.
app.get('/api/rooms/public', (_req, res) => {
  const publicRooms = [...rooms.values()].filter(room => room.visibility === 'public').map(({ code, title, createdAt }) => ({ code, title, createdAt }));
  res.json({ rooms: publicRooms });
});

app.post('/api/token', async (req, res) => {
  try {
    if (!livekitUrl || !apiKey || !apiSecret) {
      return res.status(503).json({ error: 'LiveKit server credentials are not configured.' });
    }

    const roomCode = String(req.body?.roomCode || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    const participantName = String(req.body?.participantName || 'Guest').trim().slice(0, 28) || 'Guest';
    const isHost = Boolean(req.body?.isHost);
    const visibility = req.body?.visibility === 'public' ? 'public' : 'private';

    if (roomCode.length < 4) {
      return res.status(400).json({ error: 'Room code must be at least 4 characters.' });
    }

    if (isHost) {
      rooms.set(roomCode, { code: roomCode, title: `${participantName}'s Orbit room`, visibility, createdAt: new Date().toISOString() });
    } else if (!rooms.has(roomCode)) {
      return res.status(404).json({ error: 'Room not found or no longer available.' });
    }

    // The opaque room name prevents participants from guessing the room from a short invite code.
    const roomName = `orbit-${roomCode.toLowerCase()}`;
    const identity = randomUUID();
    const token = new AccessToken(apiKey, apiSecret, {
      identity,
      name: participantName,
      ttl: '2h',
      metadata: JSON.stringify({ app: 'orbit', role: isHost ? 'host' : 'guest' })
    });

    token.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: true,
      canPublishData: true,
      canSubscribe: true
    });

    const participantToken = await token.toJwt();
    return res.json({ server_url: livekitUrl, participant_token: participantToken });
  } catch (error) {
    console.error('token issue failed', error);
    return res.status(500).json({ error: 'Unable to issue a room token.' });
  }
});

app.listen(port, () => {
  console.log(`Orbit token server listening on :${port}`);
});
