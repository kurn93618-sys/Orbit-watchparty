package com.orbit.watchparty

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.calculateTopPadding
import androidx.compose.foundation.layout.calculateBottomPadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import io.livekit.android.LiveKit
import io.livekit.android.events.RoomEvent
import io.livekit.android.renderer.SurfaceViewRenderer
import io.livekit.android.room.Room
import io.livekit.android.RoomOptions
import io.livekit.android.room.track.DataPublishReliability
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.VideoTrack
import io.livekit.android.room.track.screencapture.ScreenCaptureParams
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF090A12)
private val Panel = Color(0xFF151725)
private val Panel2 = Color(0xFF1C2030)
private val Lavender = Color(0xFFA78BFA)
private val Mint = Color(0xFF65E8CC)
private val TextMain = Color(0xFFF4F2FF)
private val TextMuted = Color(0xFF9DA1B8)

private data class PartyState(
    val inRoom: Boolean = false,
    val busy: Boolean = false,
    val roomCode: String = "",
    val roomLabel: String = "",
    val displayName: String = "You",
    val isHost: Boolean = false,
    val micOn: Boolean = true,
    val cameraOn: Boolean = false,
    val screenSharing: Boolean = false,
    val hasRemoteScreen: Boolean = false,
    val hasRemoteCamera: Boolean = false,
    val participantCount: Int = 1,
    val connectionLabel: String = "Ready when you are",
    val error: String? = null,
    val reactions: List<String> = emptyList()
)

private data class PartyMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String,
    val text: String = "",
    val gifUrl: String? = null,
    val system: Boolean = false,
    val mine: Boolean = false
)

class MainActivity : ComponentActivity() {
    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private var liveRoom: Room? = null
    private var remoteScreenTrack: VideoTrack? = null
    private var remoteCameraTrack: VideoTrack? = null
    private var renderer: SurfaceViewRenderer? = null
    private var cameraRenderer: SurfaceViewRenderer? = null
    private var party by mutableStateOf(PartyState())
    private var darkMode by mutableStateOf(true)
    private val messages = mutableStateListOf<PartyMessage>()
    private var pendingJoin: PendingJoin? = null

    private data class PendingJoin(val code: String, val name: String, val host: Boolean, val visibility: String = "private")

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val request = pendingJoin
        pendingJoin = null
        if (request != null) {
            if (grants[Manifest.permission.RECORD_AUDIO] == false) {
                Toast.makeText(this, "Microphone permission is off. You can still join and listen.", Toast.LENGTH_LONG).show()
            }
            connectToParty(request)
        }
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode != Activity.RESULT_OK || data == null) return@registerForActivityResult
        lifecycleScope.launch {
            runCatching {
                val ok = liveRoom?.localParticipant?.setScreenShareEnabled(
                    true,
                    ScreenCaptureParams(mediaProjectionPermissionResultData = data)
                ) ?: false
                if (!ok) throw IllegalStateException("Screen sharing could not start")
                party = party.copy(screenSharing = true, connectionLabel = "Your screen is live")
            }.onFailure {
                party = party.copy(error = it.message ?: "Unable to start screen sharing")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 18)
        setContent {
            MaterialTheme {
                Surface(color = Ink, modifier = Modifier.fillMaxSize()) {
                    if (party.inRoom) {
                        RoomScreen(
                            state = party,
                            messages = messages,
                            onLeave = ::leaveParty,
                            onCopyInvite = ::copyInvite,
                            onShareScreen = ::toggleScreenShare,
                            onMic = ::toggleMic,
                            onCamera = ::toggleCamera,
                            onSync = ::sendSync,
                            onSendText = ::sendChat,
                            onSendGif = ::sendGif,
                            onReaction = ::sendReaction,
                            onRendererReady = ::attachRenderer,
                            onCameraRendererReady = ::attachCameraRenderer,
                            darkMode = darkMode,
                            onToggleTheme = { darkMode = !darkMode }
                        )
                    } else {
                        HomeScreen(
                            error = party.error,
                            busy = party.busy,
                            onCreate = { name, visibility -> createParty(name, visibility) },
                            onJoin = { code, name -> joinParty(code, name) },
                            onClearError = { party = party.copy(error = null) },
                            darkMode = darkMode,
                            onToggleTheme = { darkMode = !darkMode }
                        )
                    }
                }
            }
        }
    }

    private fun createParty(name: String, visibility: String) {
        val code = (1..6).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString("")
        requestPermissionsAndJoin(PendingJoin(code, name, true, visibility))
    }

    private fun joinParty(codeInput: String, name: String) {
        val code = codeInput.uppercase().filter { it.isLetterOrDigit() }.take(8)
        if (code.length < 4) {
            party = party.copy(error = "Enter the room code (at least 4 characters).")
            return
        }
        requestPermissionsAndJoin(PendingJoin(code, name, false))
    }

    private fun requestPermissionsAndJoin(request: PendingJoin) {
        val missing = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
            .filter { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            connectToParty(request)
        } else {
            pendingJoin = request
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun connectToParty(request: PendingJoin) {
        if (BuildConfig.API_BASE_URL.contains("replace-me.example")) {
            party = party.copy(error = "Add your backend URL in gradle.properties before joining.")
            return
        }
        party = PartyState(
            busy = true,
            roomCode = request.code,
            roomLabel = "Orbit room ${request.code}",
            displayName = request.name.ifBlank { "Guest" },
            isHost = request.host,
            connectionLabel = "Connecting securely…"
        )
        lifecycleScope.launch {
            try {
                val credentials = withContext(Dispatchers.IO) { fetchToken(request) }
                val room = LiveKit.create(
                    applicationContext,
                    RoomOptions(adaptiveStream = true, dynacast = true)
                )
                liveRoom = room
                lifecycleScope.launch { collectRoomEvents(room) }
                room.connect(credentials.first, credentials.second)
                runCatching { room.localParticipant.setMicrophoneEnabled(true) }
                party = party.copy(
                    inRoom = true,
                    busy = false,
                    micOn = true,
                    connectionLabel = "Connected · room is live",
                    participantCount = 1
                )
                messages.clear()
                messages.add(PartyMessage(sender = "Orbit", text = "You're in. Keep the chat kind and the stream smooth.", system = true))
            } catch (error: Exception) {
                liveRoom?.let { runCatching { it.disconnect() } }
                liveRoom = null
                party = party.copy(
                    inRoom = false,
                    busy = false,
                    error = error.message ?: "Couldn't join this room. Check your server URL and connection."
                )
            }
        }
    }

    private fun fetchToken(request: PendingJoin): Pair<String, String> {
        val payload = JSONObject()
            .put("roomCode", request.code)
            .put("participantName", request.name.ifBlank { "Guest" })
            .put("isHost", request.host)
            .put("visibility", request.visibility)
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val url = BuildConfig.API_BASE_URL.trimEnd('/') + "/api/token"
        val httpRequest = Request.Builder().url(url).post(body).build()
        http.newCall(httpRequest).execute().use { response ->
            val resultText = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Token server ${response.code}: ${resultText.take(180)}")
            val json = JSONObject(resultText)
            return json.getString("server_url") to json.getString("participant_token")
        }
    }

    private suspend fun collectRoomEvents(room: Room) {
        room.events.collect { event ->
            when (event) {
                is RoomEvent.TrackSubscribed -> {
                    val video = event.track as? VideoTrack
                    when (event.publication.source) {
                        Track.Source.SCREEN_SHARE -> if (video != null) {
                            remoteScreenTrack = video
                            party = party.copy(hasRemoteScreen = true, connectionLabel = "Watching a live screen")
                            renderer?.let { video.addRenderer(it) }
                        }
                        Track.Source.CAMERA -> if (video != null) {
                            remoteCameraTrack = video
                            party = party.copy(hasRemoteCamera = true)
                            cameraRenderer?.let { video.addRenderer(it) }
                        }
                        else -> Unit
                    }
                }
                is RoomEvent.TrackUnsubscribed -> {
                    when (event.publications.source) {
                        Track.Source.SCREEN_SHARE -> {
                            (event.track as? VideoTrack)?.let { track -> renderer?.let(track::removeRenderer) }
                            remoteScreenTrack = null
                            party = party.copy(hasRemoteScreen = false, connectionLabel = "Waiting for a screen")
                        }
                        Track.Source.CAMERA -> {
                            (event.track as? VideoTrack)?.let { track -> cameraRenderer?.let(track::removeRenderer) }
                            remoteCameraTrack = null
                            party = party.copy(hasRemoteCamera = false)
                        }
                        else -> Unit
                    }
                }
                is RoomEvent.ParticipantConnected -> {
                    party = party.copy(participantCount = room.remoteParticipants.size + 1)
                }
                is RoomEvent.ParticipantDisconnected -> {
                    party = party.copy(participantCount = room.remoteParticipants.size + 1)
                }
                is RoomEvent.DataReceived -> receivePacket(event.data, event.participant?.name ?: "Guest")
                is RoomEvent.Reconnecting -> party = party.copy(connectionLabel = "Reconnecting…")
                is RoomEvent.Reconnected -> party = party.copy(connectionLabel = "Back in sync")
                is RoomEvent.Disconnected -> party = party.copy(connectionLabel = "Disconnected")
                else -> Unit
            }
        }
    }

    private fun receivePacket(bytes: ByteArray, sender: String) {
        runCatching {
            val json = JSONObject(bytes.toString(Charsets.UTF_8))
            when (json.optString("type")) {
                "chat" -> messages.add(PartyMessage(sender = json.optString("sender", sender), text = json.optString("text")))
                "gif" -> messages.add(PartyMessage(sender = json.optString("sender", sender), gifUrl = json.optString("url")))
                "reaction" -> {
                    val emoji = json.optString("emoji")
                    if (emoji.isNotBlank()) party = party.copy(reactions = (party.reactions + emoji).takeLast(8))
                }
                "sync_request" -> messages.add(PartyMessage(sender = "Orbit", text = "$sender asked the host for a sync cue.", system = true))
                "sync_all" -> messages.add(PartyMessage(sender = "Orbit", text = "The host sent a sync cue. Align your playback with the shared screen.", system = true))
            }
        }
    }

    private fun sendPacket(json: JSONObject, reliable: Boolean = true) {
        val room = liveRoom ?: return
        lifecycleScope.launch {
            runCatching {
                room.localParticipant.publishData(
                    json.toString().toByteArray(Charsets.UTF_8),
                    if (reliable) DataPublishReliability.RELIABLE else DataPublishReliability.LOSSY,
                    "orbit.party"
                ).getOrThrow()
            }.onFailure { party = party.copy(error = "Message could not be sent: ${it.message}") }
        }
    }

    private fun sendChat(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        messages.add(PartyMessage(sender = party.displayName, text = trimmed, mine = true))
        sendPacket(JSONObject().put("type", "chat").put("sender", party.displayName).put("text", trimmed))
    }

    private fun sendGif(url: String) {
        val trimmed = url.trim()
        if (!trimmed.startsWith("https://") || !trimmed.contains(".gif", ignoreCase = true)) {
            party = party.copy(error = "Paste a secure direct GIF image URL ending in .gif.")
            return
        }
        messages.add(PartyMessage(sender = party.displayName, gifUrl = trimmed, mine = true))
        sendPacket(JSONObject().put("type", "gif").put("sender", party.displayName).put("url", trimmed))
    }

    private fun sendReaction(emoji: String) {
        party = party.copy(reactions = (party.reactions + emoji).takeLast(8))
        sendPacket(JSONObject().put("type", "reaction").put("emoji", emoji), reliable = false)
    }

    private fun sendSync() {
        if (party.isHost) {
            sendPacket(JSONObject().put("type", "sync_all"))
            messages.add(PartyMessage(sender = "Orbit", text = "You sent a sync cue to everyone.", system = true))
        } else {
            sendPacket(JSONObject().put("type", "sync_request").put("sender", party.displayName))
            messages.add(PartyMessage(sender = "Orbit", text = "Sync request sent to the host.", system = true))
        }
    }

    private fun toggleMic() {
        val next = !party.micOn
        lifecycleScope.launch {
            runCatching { liveRoom?.localParticipant?.setMicrophoneEnabled(next) }
                .onSuccess { party = party.copy(micOn = next) }
                .onFailure { party = party.copy(error = "Microphone update failed: ${it.message}") }
        }
    }

    private fun toggleCamera() {
        val next = !party.cameraOn
        lifecycleScope.launch {
            runCatching { liveRoom?.localParticipant?.setCameraEnabled(next) }
                .onSuccess { party = party.copy(cameraOn = next) }
                .onFailure { party = party.copy(error = "Camera update failed: ${it.message}") }
        }
    }

    private fun toggleScreenShare() {
        if (party.screenSharing) {
            lifecycleScope.launch {
                runCatching { liveRoom?.localParticipant?.setScreenShareEnabled(false) }
                    .onSuccess { party = party.copy(screenSharing = false, connectionLabel = "Screen sharing stopped") }
            }
        } else {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
        }
    }

    private fun attachRenderer(view: SurfaceViewRenderer) {
        renderer = view
        liveRoom?.initVideoRenderer(view)
        remoteScreenTrack?.addRenderer(view)
    }

    private fun attachCameraRenderer(view: SurfaceViewRenderer) {
        cameraRenderer = view
        liveRoom?.initVideoRenderer(view)
        remoteCameraTrack?.addRenderer(view)
    }

    private fun copyInvite() {
        val text = "Join my Orbit watch party · code ${party.roomCode}"
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Orbit invite", text))
        Toast.makeText(this, "Invite copied", Toast.LENGTH_SHORT).show()
    }

    private fun leaveParty() {
        lifecycleScope.launch { runCatching { liveRoom?.disconnect() } }
        renderer?.let { view -> remoteScreenTrack?.removeRenderer(view); view.release() }
        cameraRenderer?.let { view -> remoteCameraTrack?.removeRenderer(view); view.release() }
        remoteScreenTrack = null
        remoteCameraTrack = null
        renderer = null
        cameraRenderer = null
        liveRoom = null
        messages.clear()
        party = PartyState()
    }

    override fun onDestroy() {
        renderer?.let { view -> remoteScreenTrack?.removeRenderer(view); view.release() }
        cameraRenderer?.let { view -> remoteCameraTrack?.removeRenderer(view); view.release() }
        liveRoom?.let { room -> lifecycleScope.launch { runCatching { room.disconnect() } } }
        super.onDestroy()
    }
}

@Composable
private fun HomeScreen(
    error: String?,
    busy: Boolean,
    onCreate: (String, String) -> Unit,
    onJoin: (String, String) -> Unit,
    onClearError: () -> Unit,
    darkMode: Boolean,
    onToggleTheme: () -> Unit
) {
    var visibility by rememberSaveable { mutableStateOf("private") }
    var name by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(if (darkMode) Brush.linearGradient(listOf(Color(0xFF101326), Ink, Color(0xFF171027))) else Brush.linearGradient(listOf(Color(0xFFF6F4FF), Color(0xFFEDEBFA), Color(0xFFE9F8F4))))
            .padding(horizontal = 22.dp)
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 24.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Lavender, Mint))), contentAlignment = Alignment.Center) {
                Text("✦", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
            }
            Column {
                Text("ORBIT", color = if (darkMode) TextMain else Color(0xFF19172B), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Text("WATCH TOGETHER", color = if (darkMode) TextMuted else Color(0xFF68677C), fontSize = 9.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(if (darkMode) "☀ Light" else "☾ Dark", color = Lavender, fontSize = 11.sp, modifier = Modifier.clip(CircleShape).clickable { onToggleTheme() }.background(Panel2).padding(horizontal = 12.dp, vertical = 8.dp))
        }

        Spacer(Modifier.height(8.dp))
        Text("Your people.\nYour screen.\nOne moment.", color = if (darkMode) TextMain else Color(0xFF19172B), fontSize = 36.sp, lineHeight = 41.sp, fontWeight = FontWeight.Bold)
        Text("Share almost anything on your phone and make it a little less alone.", color = if (darkMode) TextMuted else Color(0xFF68677C), fontSize = 15.sp, lineHeight = 22.sp)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = if (darkMode) Panel else Color(0xFFFFFFFF)),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("START A PARTY", color = Lavender, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("✦  Live rooms", color = TextMuted, fontSize = 11.sp)
                }
                Text("Make the room", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 21.sp)
                NameField(name = name, onName = { name = it })
                Text("ROOM VISIBILITY", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("private", "public").forEach { option ->
                        val selected = visibility == option
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (selected) Color(0x334CDBB7) else Panel2).border(1.dp, if (selected) Mint else Color(0xFF35394F), RoundedCornerShape(13.dp)).clickable { visibility = option }.padding(12.dp)) {
                            Column { Text(if (option == "private") "🔒 Private" else "🌐 Public", color = if (selected) Mint else TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(if (option == "private") "Invite code only" else "Discoverable by anyone", color = TextMuted, fontSize = 9.sp) }
                        }
                    }
                }
                Button(
                    onClick = { onCreate(name.ifBlank { "Guest" }, visibility) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Lavender, contentColor = Ink),
                    shape = RoundedCornerShape(17.dp)
                ) {
                    Text(if (busy) "CONNECTING…" else "Create a room  ↗", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF2A2D40)))
            Text("  OR JOIN A FRIEND  ", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF2A2D40)))
        }

        Card(colors = CardDefaults.cardColors(containerColor = if (darkMode) Panel2 else Color(0xFFF9F8FF)), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Have an invite code?", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase().filter(Char::isLetterOrDigit).take(8) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("ENTER ROOM CODE", color = TextMuted, letterSpacing = 1.5.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    shape = RoundedCornerShape(15.dp),
                    colors = fieldColors()
                )
                Button(
                    onClick = { onJoin(code, name.ifBlank { "Guest" }) },
                    enabled = code.length >= 4 && !busy,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF292D42), contentColor = TextMain),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Join the room  →", fontWeight = FontWeight.SemiBold) }
            }
        }

        if (!error.isNullOrBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3B202B)), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(error, color = Color(0xFFFFC4CE), fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("×", color = TextMain, fontSize = 20.sp, modifier = Modifier.clickable { onClearError() }.padding(start = 8.dp))
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("PRIVATE ROOMS  ·  LIVE VOICE  ·  SCREEN SHARING", color = Color(0xFF737991), fontSize = 9.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun NameField(name: String, onName: (String) -> Unit) {
    OutlinedTextField(
        value = name,
        onValueChange = onName,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Your name", color = TextMuted) },
        singleLine = true,
        shape = RoundedCornerShape(15.dp),
        colors = fieldColors()
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextMain,
    unfocusedTextColor = TextMain,
    focusedBorderColor = Lavender,
    unfocusedBorderColor = Color(0xFF35394F),
    cursorColor = Mint,
    focusedContainerColor = Color(0xFF111421),
    unfocusedContainerColor = Color(0xFF111421)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomScreen(
    state: PartyState,
    messages: List<PartyMessage>,
    onLeave: () -> Unit,
    onCopyInvite: () -> Unit,
    onShareScreen: () -> Unit,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onSync: () -> Unit,
    onSendText: (String) -> Unit,
    onSendGif: (String) -> Unit,
    onReaction: (String) -> Unit,
    onRendererReady: (SurfaceViewRenderer) -> Unit,
    onCameraRendererReady: (SurfaceViewRenderer) -> Unit,
    darkMode: Boolean,
    onToggleTheme: () -> Unit
) {
    var draft by rememberSaveable { mutableStateOf("") }
    var showGifDialog by remember { mutableStateOf(false) }
    var gifUrl by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val imageLoader = remember {
        ImageLoader.Builder(context).components {
            if (android.os.Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
        }.build()
    }
    val chatListState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) chatListState.animateScrollToItem(messages.lastIndex)
    }

    if (showGifDialog) {
        AlertDialog(
            onDismissRequest = { showGifDialog = false },
            containerColor = Panel,
            title = { Text("Drop a GIF", color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paste a direct GIF URL or a Tenor / GIPHY link.", color = TextMuted, fontSize = 12.sp)
                    OutlinedTextField(value = gifUrl, onValueChange = { gifUrl = it }, singleLine = true,
                        placeholder = { Text("https://…", color = TextMuted) }, colors = fieldColors())
                }
            },
            confirmButton = {
                TextButton(onClick = { onSendGif(gifUrl); gifUrl = ""; showGifDialog = false }) {
                    Text("Send GIF", color = Mint, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showGifDialog = false }) { Text("Cancel", color = TextMuted) } }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().background(if (darkMode) Brush.verticalGradient(listOf(Color(0xFF101326), Ink)) else Brush.verticalGradient(listOf(Color(0xFFF7F5FF), Color(0xFFEDEBFA))))
            .padding(horizontal = 16.dp)
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 10.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Lavender, Mint))), contentAlignment = Alignment.Center) {
                Text("✦", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(state.roomLabel, color = if (darkMode) TextMain else Color(0xFF19172B), fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${state.participantCount} here  ·  ${state.connectionLabel}", color = if (darkMode) TextMuted else Color(0xFF68677C), fontSize = 10.sp, maxLines = 1)
            }
            Text("${state.roomCode}", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                modifier = Modifier.clip(RoundedCornerShape(11.dp)).background(Color(0x1D65E8CC)).clickable { onCopyInvite() }.padding(horizontal = 10.dp, vertical = 8.dp))
            Spacer(Modifier.width(6.dp))
            Text(if (darkMode) "☀" else "☾", color = Lavender, fontSize = 19.sp, modifier = Modifier.clickable { onToggleTheme() }.padding(horizontal = 8.dp))
            Text("⋯", color = TextMuted, fontSize = 24.sp, modifier = Modifier.clickable { onCopyInvite() }.padding(horizontal = 5.dp))
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(0.88f, fill = true).clip(RoundedCornerShape(25.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1B2038), Color(0xFF111421), Color(0xFF211A34))))
                .border(1.dp, Color(0xFF30344B), RoundedCornerShape(25.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (state.hasRemoteScreen) {
                AndroidView(
                    factory = { ctx -> SurfaceViewRenderer(ctx).also(onRendererReady) },
                    modifier = Modifier.fillMaxSize()
                )
                if (state.hasRemoteCamera) {
                    AndroidView(
                        factory = { ctx -> SurfaceViewRenderer(ctx).also(onCameraRendererReady) },
                        modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp).size(width = 104.dp, height = 142.dp)
                            .clip(RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF69617F), RoundedCornerShape(16.dp))
                    )
                }
            } else if (state.hasRemoteCamera) {
                AndroidView(
                    factory = { ctx -> SurfaceViewRenderer(ctx).also(onCameraRendererReady) },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0x2EA78BFA)), contentAlignment = Alignment.Center) {
                        Text("▣", fontSize = 30.sp, color = Lavender)
                    }
                    Text(if (state.screenSharing) "You're sharing your screen" else "The screen goes here", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(if (state.screenSharing) "Switch to any app to share what you're doing" else "When someone shares, it appears live for everyone", color = TextMuted, fontSize = 11.sp)
                }
            }
            Row(Modifier.align(Alignment.TopStart).padding(13.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).background(Color(0xFFD94D69)).padding(horizontal = 9.dp, vertical = 5.dp)) {
                    Text("● LIVE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                }
                Box(Modifier.clip(CircleShape).background(Color(0xB80C0E19)).padding(horizontal = 9.dp, vertical = 5.dp)) {
                    Text(if (state.isHost) "HOST VIEW" else "PARTY VIEW", color = TextMain, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                }
            }
            Text("${state.participantCount} connected", color = TextMain, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(13.dp).clip(CircleShape).background(Color(0xB80C0E19)).padding(horizontal = 10.dp, vertical = 6.dp))
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionPill(text = if (state.screenSharing) "Stop share" else "Share screen", emphasized = true, modifier = Modifier.weight(1.25f), onClick = onShareScreen)
            ActionPill(text = if (state.isHost) "Sync everyone" else "Sync to host", emphasized = false, modifier = Modifier.weight(1f), onClick = onSync)
            ActionPill(text = "Invite +", emphasized = false, modifier = Modifier.weight(0.72f), onClick = onCopyInvite)
        }
        Text("Sync sends a cue — third-party apps may need manual alignment.", color = TextMuted, fontSize = 9.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("REACT", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            listOf("❤️", "😂", "😭", "🔥", "👏", "😮", "✨").forEach { emoji ->
                Text(emoji, fontSize = 20.sp, modifier = Modifier.clip(CircleShape).clickable { onReaction(emoji) }.padding(3.dp))
            }
            Spacer(Modifier.weight(1f))
            if (state.reactions.isNotEmpty()) Text(state.reactions.takeLast(3).joinToString(" "), fontSize = 14.sp)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LIVE CHAT", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Spacer(Modifier.weight(1f))
            Text("GIFs + messages", color = TextMuted, fontSize = 10.sp)
        }

        LazyColumn(
            state = chatListState,
            modifier = Modifier.weight(0.7f, fill = true).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                if (message.system) {
                    Text(message.text, color = TextMuted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp))
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.mine) Arrangement.End else Arrangement.Start
                    ) {
                        Column(Modifier.widthInOrFill(message.mine)) {
                            Text(if (message.mine) "YOU" else message.sender.uppercase(), color = if (message.mine) Mint else Lavender,
                                fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            if (message.gifUrl != null) {
                                AsyncImage(model = message.gifUrl, imageLoader = imageLoader, contentDescription = "GIF from ${message.sender}",
                                    modifier = Modifier.fillMaxWidth().heightIn(max = 132.dp).clip(RoundedCornerShape(13.dp)))
                            } else {
                                Text(message.text, color = TextMain, fontSize = 12.sp, lineHeight = 17.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(if (message.mine) Color(0x332D805F) else Panel2).padding(horizontal = 11.dp, vertical = 8.dp))
                            }
                        }
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Say something…", color = TextMuted, fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(17.dp),
                colors = fieldColors()
            )
            Text("GIF", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x223DE1C0)).clickable { showGifDialog = true }.padding(horizontal = 10.dp, vertical = 13.dp))
            Text("↑", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.size(44.dp).clip(CircleShape).background(Lavender).clickable { onSendText(draft); draft = "" },
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            ControlButton(label = if (state.micOn) "Mic on" else "Mic off", icon = if (state.micOn) "◖" else "×", active = state.micOn, onClick = onMic, modifier = Modifier.weight(1f))
            ControlButton(label = if (state.cameraOn) "Camera on" else "Camera off", icon = "▣", active = state.cameraOn, onClick = onCamera, modifier = Modifier.weight(1f))
            Button(onClick = onLeave, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A2432), contentColor = Color(0xFFFFC1CD))) {
                Text("Leave", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
        if (state.error != null) Text(state.error, color = Color(0xFFFFAEBB), fontSize = 10.sp, maxLines = 2)
    }
}

@Composable
private fun Modifier.widthInOrFill(mine: Boolean): Modifier = this.then(
    if (mine) Modifier.fillMaxWidth(0.88f) else Modifier.fillMaxWidth(0.88f)
)

@Composable
private fun ActionPill(text: String, emphasized: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier.height(44.dp).clip(RoundedCornerShape(15.dp))
            .background(if (emphasized) Lavender else Panel2)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (emphasized) Ink else TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
}

@Composable
private fun ControlButton(label: String, icon: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.height(50.dp).clip(RoundedCornerShape(16.dp))
            .background(if (active) Panel2 else Color(0xFF3B2630)).clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = if (active) Mint else Color(0xFFFFB4C0), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(label, color = TextMuted, fontSize = 9.sp)
    }
}
