# Build notes

This environment did not have the Android SDK, Gradle, or Android build tools installed, and outbound package downloads were unavailable. The source project and GitHub Actions build workflow are included, but an installable APK could not be compiled or device-tested here.

The APK build workflow uses a hosted Ubuntu runner with JDK 17, Gradle 8.9, and Android SDK setup, so the project can be built after it is uploaded to GitHub.

2026-11-26 update: Added selectable light/dark appearance, public/private room visibility selection, and a public room directory endpoint. Public room directory currently uses in-memory server state and needs persistent storage before production.
