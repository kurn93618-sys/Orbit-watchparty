# Orbit — Android watch party starter

A native Android starter for watching together: Android screen broadcast, LiveKit voice/video rooms, live chat, emoji reactions, GIF-link messages, and host/guest sync cues. The interface is styled as a dark, premium-feeling mobile client with soft neon accents.

## What is in this project

- **Android client** — Kotlin + Jetpack Compose.
- **Live media** — LiveKit Android SDK (WebRTC SFU) for screen tracks, mic, and camera.
- **Room chat/reactions/sync cues** — LiveKit reliable/lossy data packets.
- **Token backend** — Node.js service that signs room tokens. The LiveKit API secret stays on the server and is never put in the APK.
- **APK build workflow** — GitHub Actions creates a debug APK and uploads it as a downloadable workflow artifact.

## Important platform limitations

1. Android screen sharing uses the system MediaProjection consent dialog. The host must approve it each time the operating system requires. The app cannot silently capture the screen.
2. Some apps mark their content secure or DRM-protected. Android may show a black frame or prevent capture; Orbit cannot override that.
3. Screen capture audio is not guaranteed for every third-party app. Android playback capture is controlled by the source app and operating system.
4. **Sync cues are not remote playback control.** The Android app can broadcast a cue to everyone or let a guest ask the host for one. Android does not let a general app seek/pause/control arbitrary third-party apps on other people's phones. Everyone may still need to align playback manually. App-specific playback integration would be needed for true frame-accurate sync.
5. Network quality, device thermal limits, and the source app affect latency. The app enables LiveKit adaptive streaming and dynacast, but no client can guarantee zero lag on every network/device.
6. This starter currently renders the active shared screen plus one remote camera tile. A production multi-person video grid, moderation, accounts, abuse reporting, push notifications, and persistent chat history are follow-on work.

## 1. Create a LiveKit project

Create a project in LiveKit Cloud or deploy a self-hosted LiveKit server. Copy its WebSocket URL, API key, and API secret. Keep the API secret private.

## 2. Run the token backend

From the `server` folder:

```bash
npm install
cp .env.example .env
```

Fill `.env` with your LiveKit values, then run:

```bash
npm start
```

Deploy this Node service to an HTTPS host (Render, Railway, Fly.io, or your own server). Set the same environment variables on the host. The health endpoint is `/health`.

## 3. Configure the Android client

In the project root `gradle.properties`, add your deployed backend URL:

```properties
watchApiBaseUrl=https://YOUR-TOKEN-SERVER.example
```

Do not put LiveKit API keys or secrets in this file. The Android app only calls `/api/token` and receives a short-lived participant token.

## 4. Build the APK

### Build using Android Studio

Open this folder in Android Studio. Let Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK will be created at:

`app/build/outputs/apk/debug/app-debug.apk`

The project uses Android Gradle Plugin 8.7.3 / Gradle 8.9 and JDK 17, with Android SDK 35.

### Build using GitHub Actions

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build Orbit APK** (or push to `main` / `master`).
4. Open the finished workflow run and download the `orbit-debug-apk` artifact.
5. Unzip the artifact to get `app-debug.apk`, then install it on an Android device.

The workflow builds a debug APK for testing. A public release requires a signing key and a properly configured release build.

## 5. Try two devices

1. Install the same APK on two Android phones.
2. On the first phone, create a room and share the six-character room code.
3. On the second phone, enter that code to join.
4. Tap **Share screen** and approve Android's screen-capture prompt. Switch to another app to broadcast it.
5. Use the mic/camera controls, chat, emoji row, GIF link button, and sync controls.

Both phones need internet access and the token backend + LiveKit service must be reachable.

## Current GIF support

The chat accepts secure direct GIF image URLs ending in `.gif`, and animated GIFs render in chat. A searchable Tenor/GIPHY picker is not included because it needs a separately configured provider API key.

## Production hardening still needed

Before a public launch, add account authentication, room ownership checks, invite expiry/revocation, server-side host verification, participant limits, persistent chat storage, crash/analytics reporting, privacy controls, moderation, TURN/network testing, a signed release build, and a comprehensive device QA pass.

## Room visibility and appearance

- Room creation now offers **Private** (invite-code access) and **Public** (listed by the backend directory) visibility.
- Public room directory endpoint: `GET /api/rooms/public`.
- The home screen and room screen include a light/dark appearance toggle. Dark is the default.
- The selected room visibility is sent to the token service when the host creates the room.

Note: the current public-room directory is held in the token server's process memory. For production, replace it with persistent storage, add moderation/reporting, room capacity limits, ownership checks, and expiry/cleanup. Public directory browsing UI and persistence of the appearance preference are still follow-up work.
